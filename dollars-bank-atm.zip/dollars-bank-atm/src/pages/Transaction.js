import React from 'react';

export default function Transaction(props) {
  return <p>{props.transData}</p>;
}