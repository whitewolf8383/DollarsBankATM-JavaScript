import React from 'react';
import '../componentsStyles/headerStyles.css';

export default function Header() {
  return(
    <div className='header-displayBox'>
      <h1 className='header-displayName'>Dollars Bank</h1>
    </div>
  );
}